# Artificial Intelligence in the Built Environment (CE-451)

# Introduction to AI

# Dr. Aamir Alaud Din

# September 9, 2025

***

## Outline

**1. Objectives**

**2. The Why Section**

**3. Introduction**

**4. Applications of ML**

**5. Machine Learning and Its Types**

**6. Summary**

***

## 1. Objectives

After taking this lecture and studying, you should be able to:

- Briefly explain machine learning.

- Describe the major classes of machine learning algorithms.

- Differentiate between supervised and unsupervised learning.

***

## 2. The Why Section

- As a new comer to the world of Artificial Intelligence and Machine Learning, you should have an idea of what machine learning is.

- In this simple introductory lecture, one reason of studying this topic is to have an idea of machine learning.

- In our daily life of this century, we are surrounded by machine learning algorithms and many of the algorithms are in our pockets within a smart phone.

- The apps in the smart phone make use of machine learning.

- The second reason of studying this topic is to know some of the apps and other applications of machine learning in daily and business life.

- Just like other topics in the field of science and arts, which are divided into classes and groups, machine learning is also divided into two major categories.

- The categories are always based on some criteria and differences.

- In the same way, machine learning is also classified into two major categories.

- The last reason of studying this topic is to know the the major classes of machine learning algorithms with their examples.

***

## 3. Introduction

- Daily based unconscious use

- Examples

  - Web Search

  - Your and friends' picture recognition by Instagram and other apps etc.
  
  - YouTubes' recommendations on a video
  
  - Google maps paths searches
  
  - Identifying spam emails
  
  - Climate change recognition
  
  - Medical diagnosis
  
  - Learning of computer from data without programs

***

## 4. Applications of ML

- We will study which big companies use

- Writing programs for big data is complex job

- Machines learn and solve them like finding shortest path in google maps

- Smart phones

- Smart agriculture

- Smart manufacturing

- Climate forecasting

- Ultimate goal of AI for scientists and engineers is to build machine which have Artificial General Intelligence (AGI)

- Appears a very long goal

***

## 5. Machine Learning and Its Types

> **Definition: Machine Learning**
> Field of study that gives computers the ability to learn without being explicitly programmed.
> &mdash; Arthur Samuel (1959)

![Checkers](../images/0101.png)

**Figure 1.** Checkers play example.

- Arthur Samuel was not a good checker player

- He made computer to play thousands of games

- Computer decides which moves lead to win and which ones lead to loose

- The bigger the data the better the computer learns

![Types](../images/0102.png)

**Figure 2.** Types of machine learning algorithms.

- Wider use is of supervised learning, even in robots

## 5.1. Supervised Learning

- $Input \rightarrow Output$ both are provided

- $X \rightarrow Y$ i.e., both and $x$ and $y$ are provided

- It means learning from given right answers

- After learning, the algorithm takes $x$ and estimates $y$

|Input ($X$)|Output ($Y$)|Application|
|:---|:---|:---|
|Email|Spam? (0/1)|Spam filter|
|Audio|Text|Speech recognition|
|English|Japanese|Machine translation|
|Ads, Customer info|Product clicks?|Online advertisement|
|Image recognition, Radar data|Self driving cars|self-driving|
|Image of phone|Defct? (0/1)|Visual inspection|
|Climate data|Clourd bursts|Disaster identification|
|Sensor in soil (moisture, pressure, temperature)|Irrigation? (0/1)|Machine irrigation|
|Sensors in water (color, pH, ... etc)|Pollutants identification|Treatment recommendation|

- In all of the above examples and similar ones, input and the correct output are provided

- After training of learning algorithm from input output, and $x-y$ pairs, a new input $x$ is provided and the machine estimates the correct output $y$

![Price](../images/0103.png)

**Figure 3.** Regression model for price estimation of a plot.

- What will be the price of a 1678 $ft^2$ plot?

- Other better algorithms than regression are also available

- Which model to use, we will learn

- The bigger the input data, the better the estimation

- Classification

- Weather forecast

|Humidity (%)|Precipitation (%)|Numeric Translation|
|:---|:---|:---|
|70|Yes|1|
|25|No|0|
|78|Yes|1|
|65|No|0|
|82|No|0|
|37|Yes|1|

![Precipitation](../images/0104.png)

**Figure 4.** Precipitation forecast.

- Not a regression model as it has only two output, yes or no

- This is classification model

- Classification algoriths may have to predict more than two outcomes

- The terms of class or category refers to classification problem

- The output may or may not be numeric

- The number is a whole number relevant to an outcome

- There may be more than two inputs

|Humidity (%)|Pressure (atm)|Precipitation|
|:---|:---|:---|
|38|0.95|1|
|59|0.70|0|
|54|0.82|0|
|37|0.96|1|
|49|0.88|0|
|56|0.87|1|
|80|0.93|1|

![Precipitation2](../images/0105.png)

**Figure 5.** Classification of precipitation forecase based on humidity and air pressure.

- The boundary line helps in making decision

- A new input can produce the output

## 5.2. Unsupervised Learning

- In supervised learning classification problem, each input was associated with an output label y.

- The classes were represented by two different markers on the plot.

- In unsupervised learning, output variable is not labeled.

- Therefore, classes will be represented by the same marker on the plot as shown below.

![Compare](../images/0106.png)

**Figure 6.** Graphical representation of supervised and unsupervised classification.

- For example, precipitation forecast classification with unsupervised learning.

- The algorithm is not provided with $y$ labels but it has to identify the patterns and determine the label by itself.

- Unsupervised algorithm finds clusters as shown below.

![cluster](../images/0107.png)

**Figure 7.** Unsupervised clustering for classification.

- You watch videos on YouTube and it finds cluster of videos based on your keywords and suggests similar videos to you.

- In the DNA microarray shown below, rows represent genes and columns represent individual micro organisms.

![dna](../images/0108.png)

**Figure 9.** DNA microarray.

- Each row represents characterisitics, for example, color, temperature tolerance, radiation tolerance, oxygen consumers, and other characteristics.

- Each colum is an individual micro organism.

- The color represents the strength of characteristics.

- Unsupervised learning algorithms can classify mirco organisms into classes with common features.

- Note that, we don't tell the characteristics in advance to the algorithm but it has to decide itself based on colors, so, this is unsupervised clustering.

- In class of CE-451, there may be cluster who want to learn AI for their future.

- There might be cluster who want to take CE-451 because they are more comfortable with intense math and programming than with the theoretical subjects and so on.

- So, unsupervised algorithm takes data without $y$ labels and automatically finds clusters of data for classification.

> Definition: Unsupervised Learning
> Data only comes with inupts $x$ but not output labels $y$. Algorithm has to find structure in the data by itself.

- Some other interesting applications of unsupervised learning are:

  - Anomaly detection: Find unusual data points, for example, finding fraudulent financial transactions.

  - Dimensionality reduction: Input dataset is much larger (many columns) and you compress the data using fewer columns, for example, image size compression reduction.

- In the upcoming lecture, we may dive deep into some of the topics.

***

## 6. Summary

- **Supervised Learning:** Learning from given right answers

|Regression|Classification|
|:---|:---|
|Predict a number|Predict category|
|Infinitely many possible outputs|Two or more categories|

- **Unsupervised Learning:** Learning without provision of right answers or $y$ labels.

- Clustering is an example of unsupervised learning.

- Anomaly detection and dimension reduction are other examples of unsupervised learning algorithms.