import numpy as np
import matplotlib.pyplot as plt

def compute_model(w, b, x):
    return w*x + b

def compute_dj_dw(compute_model, x, y):
    return (1/m)*np.dot((compute_model - y), x)

def compute_dj_db(compute_model, y):
    return (1/m)*np.sum((compute_model - y))


w = 135
b = 71271
alpha = 0.0001

data = open("data.txt", "r")
lines = data.readlines()
data.close()

x = []
y = []
for line in lines:
    line = line.split(",")
    x.append(float(line[0]))
    y.append(float(line[1]))

x = np.array(x)
y = np.array(y)
m = len(x)
print(x)

f = compute_model(w, b, x)
print(f)

diff_w = 1
diff_b = 1

print("Sr. No.\tw         \tb")
print("=======\t==========\t==========")
print(f"1      \t{w:.4E}\t{b:.4E}")
counter = 2
while (diff_w >= 1.0E-09) and (diff_b >= 1.0E-09):
    f = compute_model(w, b, x)
    updated_w = w - alpha*compute_dj_dw(f, x, y)
    updated_b = b - alpha*compute_dj_db(f, y)
    print(f"{counter:<7d}\t{updated_w:.4E}\t{updated_b:.4E}")
    diff_w = np.abs(w - updated_w)
    diff_b = np.abs(b - updated_b)
    w = updated_w
    b = updated_b
    counter += 1
