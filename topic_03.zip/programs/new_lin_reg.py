import numpy as np

data = np.loadtxt("data1.csv", delimiter=",")
x = data[:,0]
y = data[:,1]

m = len(x)
w = 0.0
b = 0.0
alpha = 0.00000001
tol = 1e-9

diff_w, diff_b = 1.0, 1.0
iteration = 0
max_iter = 100000  # safety stop

while (diff_w > tol or diff_b > tol) and iteration < max_iter:
    y_pred = w*x + b
    error = y_pred - y
    
    neww = w - (alpha/m) * np.dot(error, x)
    newb = b - (alpha/m) * np.sum(error)
    
    diff_w = abs(neww - w)
    diff_b = abs(newb - b)
    
    if iteration % 1000 == 0:
        print(f"Iter {iteration}: w={neww:.6f}, b={newb:.6f}")
    
    w, b = neww, newb
    iteration += 1

print("Final:", w, b)
