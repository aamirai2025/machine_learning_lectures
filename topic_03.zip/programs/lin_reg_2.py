import numpy as np

data = open("data1.csv", "r")
lines = data.readlines()
data.close()

x = []
y = []
for line in lines:
    line = line.split(",")
    x.append(float(line[0]))
    y.append(float(line[1]))

x = np.array(x)
y = np.array(y)

m = len(x)
w = 0
b = 0
alpha = 1.0e-8
diff_w = 1.0
diff_b = 1.0

while diff_w > 1.0E-09 and diff_b > 1.0E-09:
    neww = w - (alpha/m)*np.dot((w*x + b - y), x)
    newb = b - (alpha/m)*np.sum((w*x + b - y))
    diff_w = np.abs(w - neww)
    diff_b = np.abs(b - newb)
    print(neww, newb)
    w = neww
    b = newb

print(w)
print(b)