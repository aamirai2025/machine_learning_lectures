<span style="font-size: 52px; line-height: 2.0;">
$$
A = \begin{bmatrix}
a_{11} & a_{12} \\
a_{21} & a_{22} 
\end{bmatrix}
$$
</span>

<span style="font-size: 52px; line-height: 2.0;">
$$
B = \begin{bmatrix}
b_{11} & b_{12} \\
b_{21} & b_{22} 
\end{bmatrix}
$$
</span>

<span style="font-size: 52px; line-height: 2.0;">
$$
AB = \begin{bmatrix}
a_{11}b_{11}+a_{12}b_{21} & a_{11}b_{12}+a_{12}b_{22} \\
a_{21}b_{11}+a_{22}b_{21} & a_{21}b_{12}+a_{22}b_{22}
\end{bmatrix}
$$
</span>