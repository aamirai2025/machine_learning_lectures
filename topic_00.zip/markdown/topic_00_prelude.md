# Artificial Intelligence in the Built Environment (CE-451)

# Prelude

# Dr. Aamir Alaud Din

# September 9, 2025

***

# Enrollment Code: 895637012

***

## Outline

**1. About the Instructor**

**2. About the Course**

**3. Lecture Format**

**4. Assessments**

**5. Course Contents**

**6. Class Rules**

**7. Books**

**8. Key to Success**

***

## 1. About the Instructor

- **Name:** Aamir Alaud Din

- **Highest Qualification:** PhD

- **Specialized Teaching Areas:** Computational

    - Computer Programming

    - Differential Equations

    - Linear Algebra

    - Probability and Statistics

    - Numerical Methods

    - Fluid Mechanics

    - Thermodynamics

    - Multivariate Analysis

    - Machine Learning

    - Deep Learning

    - Artificial Intelligence

***

## 2. About the Course

- Depth

- Requirements

    - Computer Programming (Python)

    - **_Linear Algebra_**

    - Calculus

    - **_Optimization_**

- **Course Title:** AI in the Built Environment

- **Course Code:** CE-451

- **Credit Hours:** (3, 0)

- **Contact Hours:** 3 Hours per Week

- **Objectives:** Main objectives

    - Understanding of nature and working of a machine learning model.

    - To learn and implement the mathematics and algorithms at the back end of a machine learning model.

    - To solve data based problems pertaining to environmental engineering solutions using relevant machine learning models.

***

## 3. Lecture Format

- Recap

- Objectives

- The Whys of the Topic

- Subtopics

- Summary

***

## 4. Course Contents

|Week No.|Topic|
|:---|:---|
|1|Introduction to AI and Machine Learning Overview of AI techniques AI-based applications in Building Information Modeling Overview of AI in built environment|
|2|PEAS Concept, Inputs, Outputs, Processes, AI agents, Agent function and agent program, Agent and Environment Types|
|3|Exploration of Datasets and their Analysis Data collection and analysis techniques, Data-driven decision-making algorithms|
|4|Frequent pattern Mining, Search algorithms, Initial and goal states|
|5|Supervised vs Unsupervised Machine Learning Techniques Exploration of Supervised Learning  Techniques|
|6|Regression Analysis Linear regression Logistic Regression|
|7|Clustering, Bayes Classification, KNN Classification|
|8|Basics of Python Programming Introduction to Anaconda IDE|
|9|Mid Semester Exam|
|10|Overview of Artificial neural network (ANN) models, Usage of ANNs in different applications|
|11|Building Information Modelling Modelling in Revit|
|12|Modelling in Revit (Contd.) Basics of Python Programming in BIM|
|13|Weka’s exploration and its usage|
|14|Case Studies Intelligent transportation system Soil Mechanics|
|15|Case Studies Intelligent scheduling, resource allocation, and risk management|
|16|Case Studies Use of AI in Structural Design Open AI construction|
|17|Project/ Major Assignment Demos and Vivas|
|18|End Semester Exam|

## 5. Assessments

|Sr. No.|Assessment|Numbers|Weightage|
|:---|:---|:---|:---|
|1|Quizzes|6|15|
|2|Homeworks/Assignments|6|10|
|3|Mid Semester Exam (MSE)|1|25|
|4|End Semester Exam (ESE)|1|50|

**Note:** Use of mobile phones is not allowed in any assessment. Exchange of calculators is not allowed, bring your own calculator.

***

## 6. Attendance

- 75% Attendance to appear in ESE

- Leverage of 25% for emergencies

- Attend to understand

- Absentees lead to low grades naturally

***

## 7. Class Rules

- No cell phones usage during lecture

- No discussion/gossips with side sitters or anyone

- Attendance policy of 15 minutes

- Open to relevant questions

- Snacks/drinks allowed without noise (no breakfast, brunch, lunch etc. please)

- Open door policy in student contact hours

- Collective questions through CR

- **Books:** Lecture Notes (Hands written and printed)

***

## 8. Keys to success

1. Listening and understanding the lectures silently

2. Relevant questioning

3. Reading material

4. Preparing notes

5. Thinking algorithms wherever required

6. Finding and solving relevant problems

7. Study and practice!!!